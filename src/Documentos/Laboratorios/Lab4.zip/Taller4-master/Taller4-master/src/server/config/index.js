module.exports.default = {
    mysql : {
        host:'localhost',
        user:'root',
        password:'',
        database:'taller3'
    }
}